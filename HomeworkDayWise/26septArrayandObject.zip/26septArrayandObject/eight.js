// D)
 let product = {
  id: 101,
  details: {
    name: "Laptop",
    price: 50000,
    specs: { ram: "16GB", storage: "512GB" }
  }
};

// TODO: Write your own recursive function `deepCopy(obj)`
// that performs a deep copy.
// Use it to clone `product` and modify the nested specs.

